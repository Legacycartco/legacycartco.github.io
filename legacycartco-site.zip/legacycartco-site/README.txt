LEGACY CART CO. WEBSITE

This is a complete static website that can be hosted free on GitHub Pages.

Files:
- index.html
- styles.css
- script.js
- assets/legacy-cart-co-logo.jpg

The contact form uses FormSubmit and sends submissions to legacycartco26@gmail.com.
The first time someone submits the form, FormSubmit may email a one-time activation link.

To publish free:
1. Create or sign in to a GitHub account.
2. Create a public repository named legacycartco-site.
3. Upload all files and folders from this package.
4. Open Settings > Pages.
5. Under Build and deployment, select Deploy from a branch.
6. Choose main and /root, then Save.
7. Connect legacycartco.com after the free GitHub address is working.
